<script type="text/javascript" src="../js/jquery-1.11.1.min.js"></script>

<script type="text/javascript">

$('#transkey_gen').change(function() {		

		 var transkey = "transkey";
   
    $.post('keygen.php', {transkey: transkey},
function(data){
 
//  alert("Hi there " + data);
$('#transkey').attr('value', data);

});     

return false;		
		
});	

</script> 
 
 <footer>
    &copy; <?php echo date("Y"); ?> Royalty Solution Systems - 0245777328 / 0550350420 [ <a href="staff_console.php" style="color:yellow">Staff Console</a> | <a href="admin_console.php" style="color:yellow">Admin Console</a> ]
  </footer>

</body>
</html>