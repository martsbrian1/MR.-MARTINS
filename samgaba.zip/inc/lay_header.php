<?php
//session_start();
include("../connect/config.php");
include("../inc/title.php");

?>

<?php
$msg = "";
if (isset($_SESSION['username'])){
$sysuser   = $_SESSION['username'];
$status    = $_SESSION['status'];
$store_id  = $_SESSION['store_id'];

//print $msg .="<li><b> Welcome  $user !.</b></li>";

}else{
header('location:../index.php');
}
?>

<?php
 $qry     = mysqli_query($conn, "SELECT * FROM company");				
 $dew     = mysqli_fetch_assoc($qry);
 $company = strtoupper($dew['company']); 
 $address = strtoupper($dew['address']); 
?>

<?php
		 $qrys=mysqli_query($conn, "SELECT * FROM tbretail_stores WHERE id = '$store_id'");				
		 $dews  = mysqli_fetch_assoc($qrys);
		 $store = strtoupper($dews['store']); 
		 $store = strtoupper($store); 
		
	?>

<script>
function printContent(el){
	var restorepage = document.body.innerHTML;
	var printcontent = document.getElementById(el).innerHTML;
	document.body.innerHTML = printcontent;
	window.print();
	document.body.innerHTML = restorepage;
}
</script>


<!DOCTYPE html>
<html lang="en">
<head 
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo @$title;?> </title>
<script type="text/jscript" src="../js/jquery-1.11.1.min.js"></script>
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../styles/nice_up.css" rel="stylesheet" type="text/css">

