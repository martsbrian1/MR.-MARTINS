<?php
session_start();
include("../connect/config.php");
include("../inc/title.php");

?>

<?php
$msg = "";
if (isset($_SESSION['username'])){
$sysuser   = $_SESSION['username'];
$status    = $_SESSION['status'];

//print $msg .="<li><b> Welcome  $user !.</b></li>";

}else{
header('location:../index.php');
}
?>

<?php
 $qry=mysqli_query($conn, "SELECT * FROM company");				
 $dew = mysqli_fetch_assoc($qry);
 $company = strtoupper($dew['company']); 
 $address = strtoupper($dew['address']); 
?>

<script>
function printContent(el){
	var restorepage = document.body.innerHTML;
	var printcontent = document.getElementById(el).innerHTML;
	document.body.innerHTML = printcontent;
	window.print();
	document.body.innerHTML = restorepage;
}
</script>
	
  <!-- Header -->  

<style>
.fly{
	border-radius:15px;
}
.net{
	align:right;
}
.flye{
	background-color:green;
	color: white;
	border-radius:8px;
	padding:5px;
}
</style>
  
  
  
  
  <header>
  <div class="d-flex align-items-center">    
    <h2 class="mb-0 text-white" style="text-align:center; line-height:8px"><strong><?php echo @$company; ?></strong></h2>
  </div>
   <div style="text-align:right; font-size:13px; color:#fff; margin-top:-25px;margin-right: 50px"><?php echo date("l jS \of F Y");?>
  <?php echo ucwords("$msg"); ?></div>
</header>


  <!-- Sidebar -->  
<?php include"../inc/lay_sidebar.php";?>

  <!-- Main content -->
  <div class="content">
	<div class = "new_products" >
	<div class = "row" style = "padding-left:90px" >
  <div class="dew"> <span style="color:blue; font-size:24px"><a href="#" title="Home"><?php echo @$title_main;?></a></span> </div>
   <h2>Total No. of Clients: <?php echo $nr; ?></h2>