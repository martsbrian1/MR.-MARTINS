<aside id="top-sidebar">
	<!-- Logo at the top -->
  <div class="sidebar-logo">
    <img src="../images/logo.png" width=180px;  alt="Company Logo">
  </div>
    
      <ul id ="side-ul">
        <li><a href="./logout.php">Logout</a></li>
        <li><a href="">Help</a></li>
        <li><a href="products_on_sale.php">Home</a></li>
		<li><a href="search.php">Search</a></li>
		<!--<li><a href="./add_client.php">Add New Client</a></li>
		<li><a href="search.php">Search</a></li>-->
        <!--<legend style="color:blue;font-weight:bold">Search</legend>
		<li><a href="./products_on_sale.php">All Products</a></li>-->
		
      </ul>
    
  </aside>