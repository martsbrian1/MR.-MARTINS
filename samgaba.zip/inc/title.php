<?php
if(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'index') {
	$title = "Home";
}else if(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'home') {
$title = "General Items | Eagle";
$title_main = "General Items";


	
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'add_expense') { 
	$title = "Add Expense | Eagle";
	$title_main = "Add Expense";

}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'cur_stock') { 
	$title = "Current Stock | Eagle";
	$title_main = "Current Stock";
	
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'view_categories') { 
	$title = "View Categories | Eagle";
	$title_main = "View Categories";

}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'make_payment') { 
	$title = "Receive Payment | Eagle";
	$title_main = "Receive Payment";

}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'admin_console') { 
	$title = "Admin Console | Eagle";
	$title_main = "Admin Console";   

}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'staff_console') { 
	$title = "Staff Console | Eagle";
	$title_main = "Staff Console";   
	
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'viewCus_acc') { 
	$title = "Customer's Account | Eagle";
	$title_main = "Customer's Account";

}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'add_product') { 
	$title = "Add Product | Eagle";
	$title_main = "Add Product";
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'add_suppliers') { 
	$title = "Add Supplier | Eagle";
	$title_main = "Add Supplier";

}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'add_customer') { 
	$title = "Add Customer | Eagle";
	$title_main = "Add Customer";
	
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'view_customers') { 
	$title = "View Customers | Eagle";
	$title_main = "View Customers";
	
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'search_prod') { 
	$title = "Search Product | Eagle";
	$title_main = "Search Product";
	
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'add_retailStores') { 
	$title = "Add Retail Store | Eagle";
	$title_main = "Add Retail Store";
	
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'modify_cus_payments') { 
	$title = "Modify Client Payments | Eagle";
	$title_main = "Modify Client Payments";
	
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'products_on_sale') { 
	$title = "Items On Sale| Eagle";
	$title_main = "Items On Sale";
	
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'createNew_user') { 
	$title = "Create User | Eagle";
	$title_main = "Create User";
	
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'update_prices') { 
	$title = "Update Prices | Eagle";
	$title_main = "Update Prices";
	
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'update_openingBal') { 
	$title = "Update Opening Balance | Eagle";
	$title_main = "Update Opening Balance";
	
	
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'cus_account') { 
	$title = "Customer Accounts | Eagle";
	$title_main = "Customer Accounts";
	
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'view_suppliers') { 
	$title = "View Suppliers | Eagle";
	$title_main = "View Suppliers";    
	
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'make_supplier_payment') { 
	$title = "Make Supplier Payment | Eagle";
	$title_main = "Make Supplier Payment";
		
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'sup_account') { 
	$title = "View Supplier Account | Eagle";
	$title_main = "View Supplier Account";
		
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'sales_account') { 
	$title = "Sales Account | Eagle";
	$title_main = "Sales Account";
		
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'view_customers_all') { 
	$title = "View Customers & Receive Payment  | Eagle";
	$title_main = "View Customers; Receive Payment;  View Account";
		
}elseif(basename($_SERVER['SCRIPT_FILENAME'], '.php') == 'admin_console') { 
	$title = "Admin Console | Eagle";
	$title_main = "Admin Console";
		
}	

?>