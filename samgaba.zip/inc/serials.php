<?php

function serialNumber ()
{
	return strtoupper(substr(md5(mt_rand(0, 9999999)), 0, 6));
}

