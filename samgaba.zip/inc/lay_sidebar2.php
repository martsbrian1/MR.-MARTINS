<aside id="top-sidebar">
	<!-- Logo at the top -->
  <div class="sidebar-logo">
    <img src="../images/logo.png" width=180px;  alt="Company Logo">
  </div>
    <nav>
      <ul>
        <li><a href="./logout.php">Logout</a></li>
        <li><a href="help_pharm.php">Help</a></li>
        <li><a href="search_prod.php">Search</a></li>
        <legend style="color:blue;font-weight:bold">SALES</legend>
		<li><a href="./products_on_sale.php">All Products</a></li>
		<?php 
	    /* $inv = "SELECT * FROM categories Order by name";
	    $result = mysqli_query($conn, $inv);		
	     while($col = mysqli_fetch_assoc($result)){
			 $cid=$col["id"];
	         $links =  "<li>".$col['name']."</li>"; */
		?>
        <span style="font-size:16px">
           <?php 
		   //echo "<a href= ./products_on_sale.php?cmd=$cid>".($links)."</a>";
		   //} ?>
        </span>
		
        
       <!-- <legend style="color:blue;font-weight:bold">REPORTS</legend>
        <li><a href="./day_sales_rpt.php">Sales Report</a></li>
        <li><a href="./add_expense.php">Add Expenses</a></li>
        <li><a href="./view_cash_acc.php">Sales / Expenditure Report</a></li>
        <li><a href="./staff_sales_acc.php">Staff Transaction Report</a></li>
        <li><a href="./stock_taking_sheet.php">Stock Taking Sheet</a></li> -->
      </ul>
    </nav>
  </aside>