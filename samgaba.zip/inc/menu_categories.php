<?php
//session_start(); // Needed for cart functionality

$conn = mysqli_connect("localhost", "root", "", "pos_db");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>


<style>



</style>    

	<div class="sidebar">
    <div class="logo">
        <img src="../images/logo.png" alt="">
    </div>

    <h2>Menu</h2>
	
	
	
    <a href="logout.php">logout</a>
	<a href="catalog.php">Home</a>
    <!--<a href="catalog.php?category=all">Products</a>-->
	    <a href="prod_listing.php">Products</a>
	
	<?php 
	    $inv = "SELECT * FROM categories Order by name";
	    $result = mysqli_query($conn, $inv);		
	     while($col = mysqli_fetch_assoc($result)){
			 $cid=$col["id"];
	         $links =  "<li>".$col['name']."</li>";
	?>
        <span style="font-size:16px">
           <?php 
		   echo "<a href='?cmd=$cid'>".strtoupper($links)."</a>";
		   } ?>
        </span>
   
	
	
</div>
