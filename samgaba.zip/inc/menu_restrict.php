<style>



</style>    

	<div class="sidebar">
    <div class="logo">
        <img src="../images/logo.png" alt="MyShop Logo">
    </div>

    <h2>Menu</h2>
	
	
	
    <a href="logout.php">logout</a>
	<a href="catalog.php">Home</a>
    <a href="catalog.php?category=all">Products</a>
   
	
	
</div>
